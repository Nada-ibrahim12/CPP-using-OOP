#include "BigReal.h"

bool BigReal::IS_VALID(string& number) {//Check if the input number is valid or not
    bool res = true;
    string tmp;
    swap(tmp,number);
    if (tmp[0]=='+'||tmp[0]=='-'){//erase the sign if exist
        tmp.erase(0,1);
    }
    if (count(tmp.begin(), tmp.end(), '.') > 1) {//if "." is existing in the number or not
        res = false;
    }
    if (tmp.find('.') != tmp.npos && count(tmp.begin(), tmp.end(), '.') == 1) {//if "." is existing in the number
        tmp.erase(remove(tmp.begin(), tmp.end(),'.'),tmp.end());
    }
    if (!regex_match(tmp, regex("[0-9]+"))) {//check if all number is digits
        res = false;
    }
    if (!isdigit(tmp[0]) && !isdigit(tmp[1])) {//if exist more than one sign it is false
        res = false;
    }
    return res;
}


BigReal BigReal::operator-(BigReal& other) {
    BigReal res; // Create a BigReal object to store the result of subtraction.
    int size1 = this->integer.size(), size1f = this->fraction.size();
    int size2 = other.integer.size(), size2f = other.fraction.size();

    // Make sure the fraction parts have the same length by padding with zeros.
    if (size1f < size2f) {
        for (int i = 0; i < size2f - size1f; ++i) {
            fraction += "0";
        }
    } else if (size1f > size2f) {
        for (int i = 0; i < size1f - size2f; ++i) {
            other.fraction += "0";
        }
    }

    // Make sure the integer parts have the same length by padding with zeros.
    if (size1 < size2) {
        for (int i = 0; i < size2 - size1; ++i) {
            integer = "0" + integer;
        }
    } else if (size1 > size2) {
        for (int i = 0; i < size1 - size2; ++i) {
            other.integer = "0" + other.integer;
        }
    }

    int borrow = 0; // Initialize the borrow for subtraction.

    if (sign == '+' && other.sign == '+') {
        // Check if this number is less than the other number. If so, swap and negate the sign.
        if (*this < other) {
            swap(*this, other);
            res.sign = '-'; // Result sign is negative.

            // Recalculate sizes for the swapped numbers.
            size1f = this->fraction.size();
            size2f = other.fraction.size();
            if (size1f < size2f) {
                for (int i = 0; i < size2f - size1f; ++i) {
                    fraction += "0";
                }
            } else if (size1f > size2f) {
                for (int i = 0; i < size1f - size2f; ++i) {
                    other.fraction += "0";
                }
            }
            size1 = this->integer.size();
            size2 = other.integer.size();
            if (size1 < size2) {
                for (int i = 0; i < size2 - size1; ++i) {
                    integer = "0" + integer;
                }
            } else if (size1 > size2) {
                for (int i = 0; i < size1 - size2; ++i) {
                    other.integer = "0" + other.integer;
                }
            }
        }

        // Perform subtraction for the fraction part.
        for (int i = this->fraction.size() - 1; i >= 0; --i) {
            int sub = (this->fraction[i] - '0' - (other.fraction[i] - '0' + borrow));
            if (sub < 0) {
                sub += 10;
                borrow = 1; // Set borrow for the next iteration.
            } else {
                borrow = 0;
            }
            if (i == fraction.size() - 1) {
                res.fraction = to_string(sub);
            } else {
                res.fraction = to_string(sub) + res.fraction;
            }
        }

        // Perform subtraction for the integer part.
        for (int i = this->integer.size() - 1; i >= 0; --i) {
            int sub = (this->integer[i] - '0' - (other.integer[i] - '0' + borrow));
            if (sub < 0) {
                sub += 10;
                borrow = 1;
            } else {
                borrow = 0;
            }
            if (i == integer.size() - 1) {
                res.integer = to_string(sub);
            } else {
                res.integer = to_string(sub) + res.integer;
            }
        }
    } else if (sign == '-' && other.sign == '+') {
        // Implement subtraction for different sign cases by negating and using addition.
        other.sign = '-';
        return *this + other;
    } else if (sign == '+' && other.sign == '-') {
        other.sign = '+';
        return *this + other;
    } else if (sign == '-' && other.sign == '-') {
        BigReal ans, tmp1, tmp2;
        other.sign = '+';
        this->sign = '+';
        tmp1 = *this;
        tmp2 = other;
        ans = *this - other;
        if (tmp1 < tmp2) {
            ans.sign = '+';
        } else {
            ans.sign = '-';
        }
        return ans;
    }
    return res; // Return the result of subtraction.
}


BigReal BigReal::operator+(BigReal& other) {
    BigReal res; // Create a BigReal object to store the result of addition.
    int size1 = this->integer.size(), size1f = this->fraction.size(); // Get the sizes of the integer and fractional parts of the current object.
    int size2 = other.integer.size(), size2f = other.fraction.size(); // Get the sizes of the integer and fractional parts of the other object.

    // Check if both numbers have the same sign (positive or negative).
    if ((this->sign == '+' && other.sign == '+') || (this->sign == '-' && other.sign == '-')) {
        // Ensure that both numbers have the same number of fractional digits.
        if (size1f < size2f) {
            for (int i = 0; i < size2f - size1f; ++i) {
                fraction += "0";
            }
        } else if (size1f > size2f) {
            for (int i = 0; i < size1f - size2f; ++i) {
                other.fraction += "0";
            }
        }

        // Ensure that both numbers have the same number of integer digits.
        if (size1 < size2) {
            for (int i = 0; i < size2 - size1; ++i) {
                integer = "0" + integer;
            }
        } else if (size1 > size2) {
            for (int i = 0; i < size1 - size2; ++i) {
                other.integer = "0" + other.integer;
            }
        }

        int carry = 0;
        // Perform addition for fractional part.
        for (int i = fraction.size() - 1; i >= 0; --i) {
            int sum = (fraction[i] - '0' + other.fraction[i] - '0' + carry);
            if (i == fraction.size() - 1) {
                res.fraction = to_string(sum % 10);
            } else {
                res.fraction = to_string(sum % 10) + res.fraction;
            }
            carry = sum / 10;
        }

        // Perform addition for integer part.
        for (int i = integer.size() - 1; i >= 0; --i) {
            int sum = (integer[i] - '0' + other.integer[i] - '0' + carry);
            if (i == integer.size() - 1) {
                res.integer = to_string(sum % 10);
            } else {
                res.integer = to_string(sum % 10) + res.integer;
            }
            carry = sum / 10;
        }

        // If there is a carry left after addition, add it to the integer part.
        if (carry > 0) {
            res.integer = to_string(carry) + res.integer;
        }

        res.sign = this->sign; // Set the sign of the result to match the input numbers.
    }
    else if (sign=='-'&&other.sign=='+'){
        sign='+'; // Change the sign of the current object to positive.
        return other-*this; // Call subtraction with the updated sign.
    } else if (sign=='+'&&other.sign=='-'){
        other.sign='+'; // Change the sign of the other object to positive.
        return *this-other; // Call subtraction with the updated sign.
    }
    return res; // Return the result of addition.
}

// Define the 'less than' operator for BigReal objects.
bool BigReal::operator<(BigReal anotherReal) {
    // Check for different signs of numbers.
    if ((this->sign == '-') && (anotherReal.sign == '+'))
        return true;
    else if ((this->sign == '+') && (anotherReal.sign == '-'))
        return false;
    else if ((this->sign == '-') && (anotherReal.sign == '-')) {
        // Both numbers are negative, so compare absolute values.
        BigReal compare1, compare2;
        compare1 = *this;
        compare1.sign = '+';
        compare2 = anotherReal;
        compare2.sign = '+';
        return (compare1 > compare2);
    } else {
        // Handle positive numbers with integer and fractional parts.
        // Remove leading zeros if they exist in integer parts.
        if (this->integer[0] == '0') {
            for (int i = 0; i < this->integer.size(); ++i) {
                if (this->integer.front() == '0')
                    this->integer.erase(this->integer.begin());
                else
                    break;
            }
        }
        if (anotherReal.integer[0] == '0') {
            for (int i = 0; i < anotherReal.integer.size(); ++i) {
                if (anotherReal.integer.front() == '0')
                    anotherReal.integer.erase(anotherReal.integer.begin());
                else
                    break;
            }
        }

        int size1 = this->integer.size(), size1f = this->fraction.size();
        int size2 = anotherReal.integer.size(), size2f = anotherReal.fraction.size();

        // Compare sizes of integer parts.
        if (size1 < size2) {
            return true;
        } else if (size1 > size2) {
            return false;
        } else {
            // If sizes are the same, compare individual digits.
            for (int i = 0; i < size1; ++i) {
                if (this->integer[i] < anotherReal.integer[i]) {
                    return true;
                } else if (this->integer[i] > anotherReal.integer[i]) {
                    return false;
                }
            }

            // Compare sizes of fractional parts, ensuring they are of the same size.
            int mx = max(size1f, size2f);
            if (size2f != size1f) {
                if (mx == size1f) {
                    for (int i = 0; i < mx; ++i) {
                        anotherReal.fraction += "0";
                    }
                } else {
                    for (int i = 0; i < mx; ++i) {
                        this->fraction += "0";
                    }
                }
            }

            // Compare individual digits in the fractional parts.
            for (int i = 0; i < mx; ++i) {
                if (this->fraction[i] < anotherReal.fraction[i] ) {
                    return true;
                } else if (this->fraction[i] > anotherReal.fraction[i]) {
                    return false;
                }
            }
        }
    }
    return false; // The numbers are equal.
}

// Define the 'greater than' operator for BigReal objects.
bool BigReal::operator>(BigReal anotherReal) {
    // Check for different signs of numbers.
    if ((this->sign == '+') && (anotherReal.sign == '-'))
        return true;
    else if ((this->sign == '-') && (anotherReal.sign == '+'))
        return false;
    else if ((this->sign == '-') && (anotherReal.sign == '-')) {
        // Both numbers are negative, so compare absolute values.
        BigReal compare1, compare2;
        compare1 = *this;
        compare1.sign = '+';
        compare2 = anotherReal;
        compare2.sign = '+';
        return (compare1 < compare2);
    } else {
        // Handle positive numbers with integer and fractional parts.
        // Remove leading zeros if they exist in integer parts.
        if (this->integer[0] == '0') {
            for (int i = 0; i < this->integer.size(); ++i) {
                if (this->integer.front() == '0')
                    this->integer.erase(this->integer.begin());
                else
                    break;
            }
        }
        if (anotherReal.integer[0] == '0') {
            for (int i = 0; i < anotherReal.integer.size(); ++i) {
                if (anotherReal.integer.front() == '0')
                    anotherReal.integer.erase(anotherReal.integer.begin());
                else
                    break;
            }
        }

        int size1 = this->integer.size(), size1f = this->fraction.size();
        int size2 = anotherReal.integer.size(), size2f = anotherReal.fraction.size();

        // Compare sizes of integer parts.
        if (size1 < size2) {
            return false;
        } else if (size1 > size2) {
            return true;
        } else {
            // If sizes are the same, compare individual digits.
            for (int i = 0; i < size1; ++i) {
                if (this->integer[i] > anotherReal.integer[i] ) {
                    return true;
                } else if (this->integer[i] < anotherReal.integer[i]) {
                    return false;
                }
            }
            // Compare sizes of fractional parts, ensuring they are of the same size.
            int mx = max(size1f, size2f);
            if (size2f != size1f) {
                if (mx == size1f) {
                    for (int i = 0; i < mx; ++i) {
                        anotherReal.fraction += "0";
                    }
                } else {
                    for (int i = 0; i < mx; ++i) {
                        this->fraction += "0";
                    }
                }
            }

            // Compare individual digits in the fractional parts.
            for (int i = 0; i < mx; ++i) {
                if (this->fraction[i] > anotherReal.fraction[i]) {
                    return true;
                } else if (this->fraction[i] < anotherReal.fraction[i]) {
                    return false;
                }
            }
        }
    }
    return false; // The numbers are equal.
}

// Define the 'equal to' operator for BigReal objects.
bool BigReal::operator==(BigReal anotherReal) {
    // Remove leading zeros if they exist in integer and fractional parts of both numbers.
    if (this->integer[0] == '0') {
        for (int i = 0; i < this->integer.size(); ++i) {
            if (this->integer.front() == '0')
                this->integer.erase(this->integer.begin());
            else
                break;
        }
    }
    if (anotherReal.integer[0] == '0') {
        for (int i = 0; i < anotherReal.integer.size(); ++i) {
            if (anotherReal.integer.front() == '0')
                anotherReal.integer.erase(anotherReal.integer.begin());
            else
                break;
        }
    }

    if (this->fraction.back() == '0') {
        for (int i = 0; i < this->fraction.size(); ++i) {
            if (this->fraction.back() == '0')
                this->fraction.pop_back();
            else
                break;
        }
    }

    if (anotherReal.fraction.back() == '0') {
        for (int i = 0; i < anotherReal.fraction.size(); ++i) {
            if (anotherReal.fraction.back() == '0')
                anotherReal.fraction.pop_back();
            else
                break;
        }
    }
    // Compare the sign, integer, and fractional parts of both numbers.
    return ((this->sign == anotherReal.sign) && (this->integer == anotherReal.integer) &&
            (this->fraction == anotherReal.fraction));
}

// Constructor to initialize a BigReal object from a string input.
BigReal::BigReal(string number) {
    if (IS_VALID(number)) { // Check if the number is valid.
        if (number[0] == '+') {
            sign = '+';
            number.erase(number.begin());
        } else if (number[0] == '-') {
            sign = '-';
            number.erase(number.begin());
        } else {
            sign = '+';
        }
        if (number.find('.') != number.npos) { // Check if "." exists in the number.
            if (number.find('.') == 0) {
                integer = "0";
                fraction = number.substr(1, number.size() - 1);
            } else if (number.find('.') == number.size() - 1) {
                number.pop_back();
                integer = number;
                fraction = "0";
            } else {
                integer = number.substr(0, number.find('.'));
                fraction = number.substr(integer.size() + 1, number.size() - 1);
            }
        } else if (number.find('.') == number.npos) {
            swap(integer,number);
            fraction = "0";
        }
    } else {
        sign = '+';
        integer = "*"; // Indicate an invalid number with '*'.
        fraction = "*";
    }
}

// Define the input operator to read a BigReal object from a stream.
istream& operator >> (istream& in, BigReal& num) {
    string input;
    in >> input;
    num = BigReal(input); // Create a BigReal object from the input string.
    return in;
}

// Define the output operator to write a BigReal object to a stream.
ostream& operator << (ostream& out, BigReal& num) {
    out << num.sign << num.integer << '.' << num.fraction; // Output the BigReal number.
    return out;
}
// Default constructor
BigReal::BigReal() {
    sign = '+';
    integer = "0";
    fraction = "0";
}