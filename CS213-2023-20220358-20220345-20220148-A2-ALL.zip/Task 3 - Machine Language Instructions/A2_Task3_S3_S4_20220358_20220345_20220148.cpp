// FCAI
//Object Oriented Programming - Assignment 2 - Task 3
//Instructor / Mohamed El-Ramly
//TA / ENG.Belal

// Nada Ibrahim Mohamed    - 20220358 - S3
// Zinab Mohamed El-Sayed  - 20220148 - S3
// Menna Hassan Helmy      - 20220345 - S4

#include <bits/stdc++.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <istream>
#include <sstream>

using namespace std;
int ans;
string IR;
deque<string>ins;

//Memory Class
class Memory {
private:
    vector<int> values;
public:
    Memory(int size = 0) {
        values.resize(size, 0);
    }

    void set_size(int size = 0) {
        values.resize(size, 0);
    }

    int get_size() {
        return values.size();
    }

    int get_val_memo(int indx) {
        if (indx >= 0 && indx < values.size()) {
            return values[indx];
        } else {
            cout << "ERROR TO GET TO THIS MEMORY.";
            return 0;
        }
    }

    int get_Memory(int location) {
        if (location >= 0 && location < values.size()) {
            return location;
        } else {
            cout << "ERROR TO GET THIS MEMORY.";
            return 0;
        }
    }

    void set_Memory(int location, int value) {
        if (location >= 0 && location < values.size()) {
            values[location] = value;
        } else {
            cout << "ERROR TO SET THIS MEMORY.";
        }
    }
};

//Register Class
class Register {
    int number;
    bool loaded; // Flag to indicate if the register is loaded
public:
    Register(int x = 0) { // default & initialization
        number = x;
        loaded = false; // Initially, the register is not loaded
    }

    void set_Reg(int x) {
        number = x;
        loaded = true; // Set the flag to true when the register is loaded
    }

    int get_Reg() {
        return number;
    }

    bool is_Loaded() {
        return loaded;
    }
};

class Operations {

public:
    //Function to load Value in register
    static void loadValueToRegister(Register &reg, int value) {
        reg.set_Reg(value);
    }

    //Function to load Value from memory to register
    static void loadFromMemoryToRegister(Register &reg, Memory &memory, int location) {
        int value = memory.get_val_memo(location);
        reg.set_Reg(value);
    }

    //Function to store the value from register to memory
    static void storeRegisterToMemory(Register &reg, Memory &memory, int location) {
        int value = reg.get_Reg();
        memory.set_Memory(location, value);
        cout << value << " stored in memory at location --> " << location << '\n';
    }

    static void storeRegisterToScreen(Register &reg, Memory &memory) {
        int value = reg.get_Reg();
        memory.set_Memory(0, value); // Assuming location 00 is the screen
        cout << value << " displayed on screen.\n";
    }

    //Function to move value from register to another one
    static void moveRegisterToRegister(Register &regSrc, Register &regDest) {
        int value = regSrc.get_Reg();
        regDest.set_Reg(value);
        cout << value << " moved to register -->" << &regDest << '\n';
    }

    //Function to add two two's complement numbers
    static void addRegisters(Register &regR, Register &regS, Register &regT) {
        if (!regS.is_Loaded() || !regT.is_Loaded()) {
            cout << "One of the source registers is not loaded before addition." << '\n';
            return;
        }
        int valueS = regS.get_Reg();
        int valueT = regT.get_Reg();

        // Perform the addition as two's complement representations
        int result = (valueS + valueT) & 0xFF;

        // Handle overflow
        if (result > INT_MAX || result < INT_MIN) {
            cout << "Overflow occurred during addition." << endl;
            // Handle overflow condition as needed, e.g., wrap around or set to maximum/minimum value.
        } else {
            regR.set_Reg(result);
        }
    }
};

//Machine Class
class Machine {
private:
    Memory memory;
    vector<Register> reg;
    int counter;
    bool shouldJump;
    int jumpAddress;

public:
    Machine(int sz_memo = 0, int sz_reg = 0, int x = 0) {
        memory.set_size(sz_memo);
        reg.resize(sz_reg, 0);
        counter = x;
        shouldJump = false;
        jumpAddress = 0;
    }

    void displayStatus() {
        display_PC();
        display_IR();
        display_Reg();
        display_Memo();
    }

    void execute(vector<vector<int>> &instructions) {
        while (counter < instructions.size()) {
            if (ans == 2) {
                displayStatus();
            }
            int opcode = instructions[counter][0];
            int operand = instructions[counter][2];
            int registerIndex = instructions[counter][1];
            int destRegisterIndex;
            int srcRegisterIndex;
            int operand2RegisterIndex = instructions[counter][2];
            switch (opcode) {
                case 1:
                    Operations::loadFromMemoryToRegister(reg[registerIndex], memory, operand);
                    break;
                case 2:
                    Operations::loadValueToRegister(reg[registerIndex], operand);
                    break;
                case 3:
                    Operations::storeRegisterToMemory(reg[registerIndex], memory, operand);
                    break;
                case 4:
                    if (registerIndex == 0) {
                        Operations::storeRegisterToScreen(reg[registerIndex], memory);
                    } else {
                        destRegisterIndex = instructions[counter][3];
                        Operations::moveRegisterToRegister(reg[registerIndex], reg[destRegisterIndex]);
                    }
                    break;
                case 5:
                    srcRegisterIndex = instructions[counter][3];
                    destRegisterIndex = instructions[counter][1];
                    Operations::addRegisters(reg[destRegisterIndex], reg[srcRegisterIndex], reg[operand2RegisterIndex]);
                    break;
                case 0xB:
                    if (reg[registerIndex].get_Reg() == reg[0].get_Reg()) {
                        jumpAddress = operand/2;
                        shouldJump = true;
                    }
                    break;
                case 0xC:
                    break;
                default:
                    break;
            }
            // Check if a jump should occur
            if (shouldJump) {
                counter = jumpAddress; // Set the program counter to the jump address
                shouldJump = false;    // Reset the jump flag
            } else {
                // Increment the program counter
                counter++;
            }
        }
    }

    void display_IR() {
        cout<<"IR = ";
        if (ins.empty()){
            cout<<"EMPTY !\n";
        } else {
            cout << ins.front() << '\n';
            ins.pop_front();
        }
    }

    void display_PC() {
        cout<<"PS = ";
        if (counter * 2 <= 15)
            cout << 0 << counter * 2 <<'\n';
        else
            cout << counter * 2 << " ";
    }

    void display_Reg() {
        cout << "Registers" << '\n' << "-------------" << '\n';
        for (int i = 0; i < reg.size(); ++i) {
            cout << "R" << i << ": ";
            if (reg[i].get_Reg() <= 15)
                cout << 0 << reg[i].get_Reg() << '\n';
            else
                cout << reg[i].get_Reg() << '\n';
        }
    }

    void display_Memo() {
        cout << "Memory" << '\n' << "--------" << '\n';
        for (int i = 0; i < memory.get_size(); ++i) {
            if (i <= 15) {
                cout << 0 << memory.get_Memory(i) << " ";
            } else {
                cout << memory.get_Memory(i) << " ";
            }
            if (memory.get_val_memo(i) <= 15)
                cout << 0 << memory.get_val_memo(i) << '\n';
            else if (memory.get_val_memo(i) > 15)
                cout << memory.get_val_memo(i) << '\n';
        }
    }
};

string toHexString(int decimalValue) {
    stringstream ss;
    ss << hex << decimalValue; // Set the stream to output in hexadecimal
    string hexValue = ss.str(); // Get the string representation in hexadecimal
    return hexValue;
}

int main() {
    cout.setf(ios::hex, ios::basefield);
    Machine machine(256, 16); // Assuming a memory size of 256 and 16 registers
    // Read instructions from a file
    string fileName;
    cout << "Please enter the file name :  ";
    cin >> fileName;
    fstream file;
    file.open(fileName, fstream::in | fstream::out);
    vector<vector<int>> instructions;
    cout << "Please choose what you want to display the status of the registers, PC, IR, memory and screen:\n"
            "1- at the end of program execution.\n"
            "2- after each step in a suitable format.\n";
    cin >> ans;
    if (file.is_open()) {
        string line;
        // Read instructions from the file
        while (getline(file, line)) {
            istringstream iss(line);
            vector<int> instruction;
            string value;
            IR=" ";
            while (iss >> value) {
                instruction.push_back(stoi(value, nullptr, 16));
            }
            for (int i = 0; i < instruction.size(); ++i) {
                IR+= toHexString(instruction[i]);
            }
            ins.push_back(IR);
            instructions.push_back(instruction);
        }
        // Close the file
        file.close();

        // Execute the program
        machine.execute(instructions);
    } else {
        cout << "Error: Unable to open the file. " << endl;
    }
    if (ans == 1) {
        machine.display_Reg();
        machine.display_Memo();
    }
    cout << "END OF THE PROGRAM." << endl;
    return 0;
}