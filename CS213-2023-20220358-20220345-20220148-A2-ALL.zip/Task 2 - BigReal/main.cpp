#include "BigReal.cpp"

int main() {
    cout << "Operations to two numbers :-" << endl;
    cout << "1- Addition operator. " << endl;
    cout << "2- Subtraction operator. " << endl;
    cout << "3- Compare operator. " << endl;
    cout << "0- To END the programme. " << endl;
    int a = 1;
    while (a != 0) {
        cout << "Enter the number of operation: ";
        cin >> a;
        if (a==0){
            break;
        }
        cout << "Please enter the two numbers : " << endl;
        BigReal n1, n2, n3;
        cin >> n1 >> n2;
        if (n1 == BigReal("+*.*")) {
            cout << "The First number is INVALID\n";
        }
        if (n2 == BigReal("+*.*")) {
            cout << "The Second number is INVALID\n";
        }
        if (n1 == BigReal("+*.*") || n2 == BigReal("+*.*")) {
            cout << "There is an ERROR\n";
            continue;
        }
        switch (a) {
            case 1:
                n3 = n1 + n2;
                cout << n3 << endl;
                break;
            case 2:
                n3 = n1 - n2;
                cout << n3 << endl;
                break;
            case 3:
                if (n1 < n2) {
                    cout << n2 << " is the greatest" << endl;
                } else if (n1 > n2) {
                    cout << n1 << " is the greatest" << endl;
                } else if (n1 == n2) {
                    cout << "two numbers are equal" << endl;
                }
            default:
                break;
        }
    }
    return 0;
}