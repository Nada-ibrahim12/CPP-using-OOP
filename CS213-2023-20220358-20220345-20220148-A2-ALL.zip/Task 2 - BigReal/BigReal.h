#ifndef BIGREAL_H
#define BIGREAL_H
#include <iostream>
#include <string>
#include <algorithm>
#include <regex>
using namespace std;

class BigReal {
private:
    char sign;
    std::string fraction, integer;
public:
    BigReal();
    BigReal(std::string);
    bool operator<(BigReal anotherReal);
    bool operator>(BigReal anotherReal);
    bool operator==(BigReal anotherReal);
    BigReal operator+(BigReal& other);
    BigReal operator-(BigReal& other);
    bool IS_VALID(std::string number);
    friend std::ostream& operator<<(std::ostream& out, BigReal& num);
    friend std::istream& operator>>(std::istream& in, BigReal& num);
};

#endif