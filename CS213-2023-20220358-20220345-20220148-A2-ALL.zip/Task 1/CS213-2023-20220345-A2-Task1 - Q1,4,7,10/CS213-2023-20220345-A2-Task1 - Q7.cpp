// FCAI – OOP Programming – 2023 - Assignment 2 - Task 1 - Q7
// Program Name: CS213-2023-20220345-A2-Task1 - Q7.cpp
// instructor / Mohamed El-Ramly
// TA / Belal
// Author and ID and Group:	Menna Hassan Helmy - 20220345 - S3
#include <iostream>
#include <vector>
using namespace std;

struct dominoT {
    int leftDots;
    int rightDots;
};
vector<dominoT> FormDominoChain(const dominoT& currentDomino, vector<dominoT>& dominos) {
    vector<dominoT> chain;
    chain.push_back(currentDomino); // Add the current domino to the chain

    if (dominos.empty()) {
        return chain; // All dominos are used, and a chain is formed.
    }

    int currentRightDots = currentDomino.rightDots;

    for (size_t i = 0; i < dominos.size(); ++i) {
        if (currentRightDots == dominos[i].leftDots) {
            dominoT nextDomino = dominos[i];
            dominos.erase(dominos.begin() + i); // Remove the used domino from the list.
            vector<dominoT> subChain = FormDominoChain(nextDomino, dominos);
            if (!subChain.empty()) {
                chain.insert(chain.end(), subChain.begin(), subChain.end()); // Add the sub-chain to the chain.
                return chain;
            }
            dominos.insert(dominos.begin() + i, nextDomino); // Put the domino back.
        }
    }

    chain.clear(); // If no valid chain can be formed, clear the chain.
    return chain;
}
vector<dominoT> FormsDominoChain(vector<dominoT> dominos) {
    vector<dominoT> chain;

    for (size_t i = 0; i < dominos.size(); ++i) {
        vector<dominoT> remainingDominos = dominos; // Make a copy of the dominos.
        remainingDominos.erase(remainingDominos.begin() + i); // Remove the current domino.
        dominoT currentDomino = dominos[i];

        chain = FormDominoChain(currentDomino, remainingDominos);

        if (!chain.empty()) {
            return chain; // Return a valid chain if found.
        }
    }

    return chain; // If no valid chain can be formed, return an empty chain.
}

int main() {
    vector<dominoT> dominoSet;

    int numDominos;
    cout << "Enter the number of dominos: ";
    cin >> numDominos;

    cout << "Enter the dominos (leftDots rightDots):" << endl;
    for (int i = 0; i < numDominos; ++i) {
        dominoT domino;
        cin >> domino.leftDots >> domino.rightDots;
        dominoSet.push_back(domino);
    }

    vector<dominoT> chain = FormsDominoChain(dominoSet);
    if (!chain.empty()) {
        cout << "Possible Domino Chain: ";
        for (int i = 0; i < chain.size() - 1; i++) {
            cout << chain[i].leftDots << "|" << chain[i].rightDots << " - ";
        }
        cout << chain.back().leftDots << "|" << chain.back().rightDots << endl;
    } else {
        cout << "No possible Domino Chain." << endl;
    }
    return 0;
}