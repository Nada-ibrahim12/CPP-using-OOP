// FCAI – OOP Programming – 2023 - Assignment 2 - Task 1 - Q4
// Program Name: CS213-2023-20220345-A2-Task1 - Q4.cpp
// instructor / Mohamed El-Ramly
// TA / Belal
// Author and ID and Group:	Menna Hassan Helmy - 20220345 - S3
#include <iostream>
#include <vector>
using namespace std;
void prime_no(int n) {
    vector<bool> prime(n + 1, true);

    // Iterate through numbers starting from 2 up to the square root of 'n'
    for (int p = 2; p * p <= n; p++) {
        // If 'p' is marked as a prime number (true), mark its multiples as non-prime
        if (prime[p] == true) {
            for (int i = p * p; i <= n; i += p) {
                prime[i] = false;
            }
        }
    }
    for (int p = 2; p <= n; p++) {
        if (prime[p]) {
            cout << p << " ";
        }
    }
    cout << endl;
}

int main() {
    int n;
    cout << "Enter a number: ";
    cin >> n;


    prime_no(n);

    return 0;
}