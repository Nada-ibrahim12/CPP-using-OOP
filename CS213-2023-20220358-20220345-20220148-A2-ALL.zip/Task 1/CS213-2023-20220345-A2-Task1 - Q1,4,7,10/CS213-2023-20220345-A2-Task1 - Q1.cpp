// FCAI – OOP Programming – 2023 - Assignment 2 - Task 1 - Q1
// Program Name: CS213-2023-20220345-A2-Task1 - Q1.cpp
// instructor / Mohamed El-Ramly
// TA / Belal
// Author and ID and Group:	Menna Hassan Helmy - 20220345 - S3
#include <iostream>
#include <string>
using namespace std;

int main() {
    string sentence;
    getline(cin, sentence);

    string correctedSentence;
    char prevchar = '\0'; // Initialize prevchar to a null character

    for (char c : sentence) {
        // Check if the current character is a space, tab, or newline
        if (c == ' ' || c == '\t' || c == '\n') {
            // If the previous character was not a space, period, or null character,
            // add a single space to the corrected sentence to replace multiple spaces.
            if (prevchar != ' ' && prevchar != '.' && prevchar != '\0')
                correctedSentence += ' ';
        } else {
            // If the current character is not a space, tab, or newline, add it to the corrected sentence.
            correctedSentence += c;
        }
        prevchar = c; // Update the previous character with the current character.
    }
    // Capitalize the first letter of the corrected sentence
    correctedSentence[0] = toupper(correctedSentence[0]);

    // Convert the rest of the sentence to lowercase
    for (int i = 1; i < correctedSentence.length(); i++) {
        correctedSentence[i] = tolower(correctedSentence[i]);
    }// Check if the last character of the sentence is not a period and add one if missing
    if (correctedSentence.back() != '.') {
        correctedSentence += '.';
    }
    cout << correctedSentence << endl;
}