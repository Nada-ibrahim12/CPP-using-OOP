// FCAI – OOP Programming – 2023 - Assignment 2 - Task 1 - Q10
// Program Name: CS213-2023-20220345-A2-Task1 - Q10.cpp
// instructor / Mohamed El-Ramly
// TA / Belal
// Author and ID and Group:	Menna Hassan Helmy - 20220345 - S3

#include <iostream>
#include <bits/stdc++.h>
using namespace std;

string replaceWord(const string& word, const vector<string>& alternatives) {
    if (alternatives.empty()) {
        return word;
    } else {
        int randomIndex = rand() % alternatives.size();
        return alternatives[randomIndex];
    }
}

int main() {
    srand(static_cast<unsigned int>(time(nullptr)));

    //lookupFile is the file that has the word and its alternative
    string lookupFileName, inputFileName, outputFileName;
    cout << "Please enter the lookup file name: ";
    cin >> lookupFileName;
    cout << "Please enter the input file name: ";
    cin >> inputFileName;
    cout << "Please enter the output file name: ";
    cin >> outputFileName;

    ifstream lookupFile(lookupFileName);
    if (!lookupFile) {
        cerr << "Error opening lookup file." << endl;
        return 1;
    }

//check the file then copy the data and insert it in map "lookupTable" (each word and its corresponding alternative)
    map<string, vector<string>> lookupTable;
    string word, alternative;

    while (lookupFile >> word >> alternative) {
        lookupTable[word].push_back(alternative);
    }

    ifstream inputFile(inputFileName);
    if (!inputFile) {
        cerr << "Error opening input file." << endl;
        return 1;
    }

    ofstream outputFile(outputFileName);
    if (!outputFile) {
        cerr << "Error opening output file." << endl;
        return 1;
    }
//search about the word that we need to change it at the inputFile if it founds, then change it with its allternative word
//then save the new strings in the outputFile
    string line;
    while (getline(inputFile, line)) {
        istringstream iss(line);
        string word;

        while (iss >> word) {
            auto it = lookupTable.find(word);
            if (it != lookupTable.end()) {
                string replacement = replaceWord(word, it->second);
                outputFile << replacement << " ";
            } else {
                outputFile << word << " ";
            }
        }

        outputFile << endl;
    }

    cout << "Message alteration complete. Modified message saved to " << outputFileName << endl;

    return 0;
}