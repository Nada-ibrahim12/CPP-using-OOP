// FCAI – OOP Programming – 2023 - Assignment 2 - Task 1 - Q12
// Program Name: CS213-2023-20220148-A2-Task1-Q12.cpp
// instructor / Mohamed El-Ramly
// TA / Belal
// Author and ID and Group:	Zinab Mohamed Elsayed - 20220148 - S3

#include <iostream>
#include <vector>
#include <deque>
#include <cmath>
#include <map>
#include <string>
#include <fstream>
#include <sstream>
#include <set>
#include <algorithm>
#include <regex>
using namespace std;

static void PhishingScanner() {
    map<string, int> phishingWords = {{"amazon",       2},
                                      {"official",     2},
                                      {"bank",         1},
                                      {"security",     1},
                                      {"urgent",       1},
                                      {"alert",        1},
                                      {"important",    1},
                                      {"information",  2},
                                      {"ebay",         3},
                                      {"password",     3},
                                      {"credit",       3},
                                      {"verify",       1},
                                      {"confirm",      1},
                                      {"account",      1},
                                      {"bill",         1},
                                      {"immediately",  1},
                                      {"address",      2},
                                      {"telephone",    2},
                                      {"ssn",          3},
                                      {"charity",      2},
                                      {"check",        1},
                                      {"secure",       1},
                                      {"personal",     1},
                                      {"confidential", 1},
                                      {"atm",          2},
                                      {"warning",      2},
                                      {"fraud",        2},
                                      {"citibank",     2},
                                      {"irs",          2},
                                      {"paypal",       1}};
    map<string, int> TotalPoints;
    ifstream file;
    cout << "Please Enter the name of email that checking : ";
    string mailName;
    cin >> mailName;
    fstream file2;
    file.open(mailName);// open the file
    file2.open("tmp.txt", fstream::in | fstream::out);
    vector<string> content; // create vector to store the file contents
    string word; //for each word in file
    while (!file.eof()) {//convert each word to lowercase and save it in new file
        file >> word;
        for (int j = 0; j < word.length(); ++j) {
            word[j] = tolower(word[j]);
        }
        file2 << word << '\n';
    }
    file2.close();
    file2.open("tmp.txt", fstream::in | fstream::out);
    while (getline(file2, word)) {//check for each word if there is at end (.or,or:or?)so delete it 
        if (word.back() == '.' || word.back() == ',' || word.back() == ':' || word.back() == '?') {
            word.pop_back();
        }
        auto it = phishingWords.find(word);
        if (it != phishingWords.end()) {//fill vector of content if the word exist in the file
            content.push_back(word);
        }
    }
    int point = 0;
    int sz = content.size();
    for (int i = 0; i < sz; ++i) {
        TotalPoints[content[i]]++;//calculate the points of content the mail
    }
    for (auto &z: TotalPoints) {//print the required
        cout << "                    Occurrence   " << " Points  \n";
        cout << z.first << "                    " << z.second << "       " << phishingWords[z.first] * z.second << "\n";
        point += (TotalPoints[z.first] * phishingWords[z.first]);
    }
    cout << "-----------------------------------------------------\n";
    cout << "                               Total = " << point << '\n';
    file.close();// close the file
    file2.close();
}

int main() {
    PhishingScanner();
}