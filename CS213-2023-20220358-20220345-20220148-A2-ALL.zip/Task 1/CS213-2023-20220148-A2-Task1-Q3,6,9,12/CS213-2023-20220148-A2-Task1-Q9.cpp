// FCAI – OOP Programming – 2023 - Assignment 2 - Task 1 - Q9
// Program Name: CS213-2023-20220148-A2-Task1-Q9.cpp
// instructor / Mohamed El-Ramly
// TA / Belal
// Author and ID and Group:	Zinab Mohamed Elsayed - 20220148 - S3

#include <iostream>
#include <vector>
#include <deque>
#include <cmath>
#include <map>
#include <string>
#include <fstream>
#include <sstream>
#include <set>
#include <algorithm>
#include <regex>
using namespace std;

set<int> number;
static bool bears(int n) {
    if (n == 42) {//when n==42 is mean we reach to the Goal
        return true;
    }
    if (number.count(n) > 0 || n < 42) {
        return false;  //if(number.count(n) > 0) --> Avoid infinite recursion by returning false if n has been encountered before in the set number
        //if(n<42) --> is mean we never reach to the Goal
    }
    number.insert(n);
    if (n % 5 == 0 && bears(n - 42)) {//if (n divisible by 5) then we subtract 42 from n and then complete
        return true;
    }
    int lastDigit = (n % 10) * ((n % 100) / 10);
    if ((n % 4 == 0 || n % 3 == 0) && bears(n - lastDigit)) {//if (n divisible by 3 or 4)
        // then we subtract (multiply of last digits) from n and then complete
        return true;
    }
    if (n % 2 == 0 && bears(n / 2)) {//if (n divisible by 2) then we divide n by 2 and then complete
        return true;
    }
    return false;//if none of the conditions are happen, return false
}


int main() {
    int num;
    cout << "Please Enter number of bears to start : ";
    cin >> num;
    cout << (bears(num) ? "It is possible to win the bear game." : " it is not possible to win the bear game.")
         << '\n';
}