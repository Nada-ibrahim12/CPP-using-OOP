// FCAI – OOP Programming – 2023 - Assignment 2 - Task 1 - Q6
// Program Name: CS213-2023-20220148-A2-Task1-Q6.cpp
// instructor / Mohamed El-Ramly
// TA / Belal
// Author and ID and Group:	Zinab Mohamed Elsayed - 20220148 - S3

#include <iostream>
#include <vector>
#include <deque>
#include <cmath>
#include <map>
#include <string>
#include <fstream>
#include <sstream>
#include <set>
#include <algorithm>
#include <regex>
using namespace std;

//Q6_a
static void binaryPrint(int n) {
    if (n == 0)
        return;
    else {
        binaryPrint(n / 2);//divided the number by 2
        cout << to_string(n % 2);//print the integer after change it to binary
    }
}

//Q6_b
static void numbers(string prefix, int k) {
    if (k == 0) {
        cout << prefix << '\n';
        return;
    }
    numbers(prefix + "0", k - 1);//doing combinations of 2 power k and adding it to the binary number that you given
    numbers(prefix + "1", k - 1);
}

int main() {
    int num;
    cout << "Please Enter the number that you want to print it as Binary :";
    cin >> num;
    if (num == 0) {
        cout << "0";
    } else {
        binaryPrint(num);
    }
    cout << '\n';
    cout << "Please Enter the prefix and k : ";
    string prefix;
    int k;
    cin >> prefix >> k;
    cout << '\n';
    numbers(prefix, k);
}