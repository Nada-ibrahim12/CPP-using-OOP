// FCAI – OOP Programming – 2023 - Assignment 2 - Task 1 - Q3
// Program Name: CS213-2023-20220148-A2-Task1-Q3.cpp
// instructor / Mohamed El-Ramly
// TA / Belal
// Author and ID and Group:	Zinab Mohamed Elsayed - 20220148 - S3

#include <iostream>
#include <vector>
#include <deque>
#include <cmath>
#include <map>
#include <string>
#include <fstream>
#include <sstream>
#include <set>
#include <algorithm>
#include <regex>
using namespace std;

vector<string> split(string target, string delimiter) {
    vector<string> ans;//first we create a vector to store the string after changes "split"
    string tmp;//store the part of string that will split
    int sz = delimiter.size();
    for (int i = 0; i < target.size();) {
        string z = target.substr(i, sz);//select the part of string before delimiter
        if (z != delimiter) {
            tmp.push_back(target[i]);//fill the tmp
            i++;
        } else {
            if (!tmp.empty()) {//if the delimiter is the first of string then did not need to add tmp because it is empty
                ans.push_back(tmp);
                tmp = "";
            }
            i += sz;
        }
    }
    if (!tmp.empty()) {//we reach to the split part then we added it into vector ans
        ans.push_back(tmp);
    }
    for (auto &z: ans) {//print the string after split
        cout << z << ' ';
    }
    return ans;
}

int main(){
    cout<<"Please enter the target string and the delimiter you want : ";
    string target,delimiter;
    getline(cin,target);
    getline(cin,delimiter);
    split(target,delimiter);
}