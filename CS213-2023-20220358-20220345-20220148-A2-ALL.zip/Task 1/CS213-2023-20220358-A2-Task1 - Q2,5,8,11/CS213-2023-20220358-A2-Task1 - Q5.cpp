// FCAI – OOP Programming – 2023 - Assignment 2 - Task 1 - Q5
// Program Name: CS213-2023-20220358-A2-Task1 - Q5.cpp
// instructor / Mohamed El-Ramly
// TA / Belal
// Author and ID and Group:	Nada Ibrahim Mohamed - 20220358 - S3

#include <bits/stdc++.h>
#include <iostream>
#include <map>
using namespace std;

multimap < string , int > m;
auto itr = m.begin();

// to get the highest player name and his score
void h_player(){
    vector<pair<int, string>> vec;
    for (auto&element:m) {
        vec.emplace_back(make_pair(element.second,element.first));
    }
    sort(vec.rbegin(), vec.rend());
    cout << vec.front().second << " , " << vec.front().first << endl ;
}

// to get all the top 10 players' names and their scores
void print(){
    //to sort the top 10 accoring to their scores, copy them to vector
    vector<pair<int, string>> vec;
    for (auto&element:m) {
        vec.emplace_back(make_pair(element.second,element.first));
    }
    sort(vec.rbegin(), vec.rend());
    for (const auto& itr : vec){
        cout << itr.second << '\t' << itr.first << endl;
    }
};
 // to add new player's name and score, then rearrange the players rank 
void add(){
    cout << "please enter player's name : " ;
    string s;
    cin >> s;
    cout << "please enter player's score : ";
    int x;
    cin >> x;
    m.insert ({s , x});
    m.erase(prev(m.end()));
}
//to search about specific player and git his score
void find_name(){
    string s;
    cout << "please enter player's name : " ;
    cin >> s;
    for (itr = m.find(s) ; itr != m.end() ; itr++) {
        cout << itr -> first << '\t' << itr -> second << endl;
        break;
    }
}

int main() {
    //Enter the 10 players' names and scores
    for (int i = 1 ; i<=10 ; i++){
        cout << "please enter player "<< i << " name : " ;
        string s;
        cin >> s;
        cout << "please enter player "<< i << " score : ";
        int x;
        cin >> x;
        m.insert ({s , x});
    }
    //to sort them accorfing their scores, copy key-value pairs from the map to the vector
    vector<pair<int, string>> vec;
    for (auto&element:m) {
        vec.emplace_back(make_pair(element.second,element.first));
    }
    sort(vec.rbegin(), vec.rend());
    cout << "if you want to do anything enter 1 : " << endl;
    int b;
    cin >> b;
    while (b==1){
        cout << "please enter the number of what you want : " << endl;
        cout << " 1: print all top 10 \n 2: add player \n 3: find player \n 4: get highest player "<< endl ;
        int a ;
        cin >> a;
        switch (a) {
            case 1:
                print();
                break;
            case 2:
                add();
                break;
            case 3:
                find_name();
                break;
            case 4:
                h_player();
                break;
            default:
                cout << "Invalid input" << endl;
                break;
        }
        cout << "if you want to continue please enter 1 : ";
        cin >> b;
    }
}


