// FCAI – OOP Programming – 2023 - Assignment 2 - Task 1 - Q8
// Program Name: CS213-2023-20220358-A2-Task1 - Q8.cpp
// instructor / Mohamed El-Ramly
// TA / Belal
// Author and ID and Group:	Nada Ibrahim Mohamed - 20220358 - S3

#include <bits/stdc++.h>
#include <iostream>
using namespace std;

static void asterisk_pattern(int num,int i) {
    if (num == 0) {
        return;
    } else if (num == 1) {
        for (int j = 0; j < i; j++) {
            cout << "  ";
        }
        cout << "* " << endl;
    } else {
        asterisk_pattern(num / 2, i);
        for (int j = 0; j < i; j++) {
            cout << "  ";
        }
        for (int j = 0; j < num; j++) {
            cout << "* ";
        }
        cout << endl;
        asterisk_pattern(num / 2, i + num / 2);
    }
}
int main() {
    int n , i;
    cout << "Enter the length of the line (a power of 2 greater than zero): ";
    cin >> n;
    cout << "Enter the starting column of the line: ";
    cin >> i;
    asterisk_pattern(n, i);
}