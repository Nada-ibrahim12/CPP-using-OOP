// FCAI – OOP Programming – 2023 - Assignment 2 - Task 1 - Q2
// Program Name: CS213-2023-20220358-A2-Task1 - Q2.cpp
// instructor / Mohamed El-Ramly
// TA / Belal
// Author and ID and Group:	Nada Ibrahim Mohamed - 20220358 - S3
#include <bits/stdc++.h>
#include <iostream>

using namespace std;

int main() {
    string str;
    cout << "Please enter your string: ";
    getline(cin, str);

//declare the word and its alternative 
    string old1 = "he ";
    string new1 = "he or she ";
    string old2 = "He ";
    string new2 = "He or She ";
    string old3 = "His ";
    string new3 = "His or Her ";
    string old4 = " his";
    string new4 = " his or her";
    string old5 = " him";
    string new5 = " him or her";
    string old6 = "Him ";
    string new6 = "Him or Her ";

    //check if one of this word is found, if it founds then change it(wordi) to its alterantive word (newi)
    size_t pos = 0;
    while ((pos = str.find(old1, pos)) != string::npos) {
        str.replace(pos, old1.length(), new1);
        pos += new1.length();
    }

    pos = 0;
    while ((pos = str.find(old2, pos)) != string::npos) {
        str.replace(pos, old2.length(), new2);
        pos += new2.length();
    }

    pos = 0;
    while ((pos = str.find(old3, pos)) != string::npos) {
        str.replace(pos, old3.length(), new3);
        pos += new3.length();
    }

    pos = 0;
    while ((pos = str.find(old4, pos)) != string::npos) {
        str.replace(pos, old4.length(), new4);
        pos += new4.length();
    }

    pos = 0;
    while ((pos = str.find(old5, pos)) != string::npos) {
        str.replace(pos, old5.length(), new5);
        pos += new5.length();
    }

    pos = 0;
    while ((pos = str.find(old6, pos)) != string::npos) {
        str.replace(pos, old6.length(), new6);
        pos += new6.length();
    }
//then print the new string after changes
    cout << str << endl;
}


