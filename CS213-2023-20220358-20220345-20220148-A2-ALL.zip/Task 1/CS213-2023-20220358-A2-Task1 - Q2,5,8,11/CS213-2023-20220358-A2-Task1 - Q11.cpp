// FCAI – OOP Programming – 2023 - Assignment 2 - Task 1 - Q11
// Program Name: CS213-2023-20220358-A2-Task1 - Q11.cpp
// instructor / Mohamed El-Ramly
// TA / Belal
// Author and ID and Group:	Nada Ibrahim Mohamed - 20220358 - S3

#include <bits/stdc++.h>
#include <iostream>
using namespace std;

void character_by_character(ifstream& myfile1, ifstream& myfile2) {
    char c1, c2;
    int l = 1;
    bool differenceFound = false;
    string line1, line2;

// to store the content of the lines where differences are found
    while (myfile1.get(c1) && myfile2.get(c2)) {
        if (c1 != c2) {
            differenceFound = true;
            line1.push_back(c1);
            line2.push_back(c2);
        }
// at the end of the line (lines) if there is a difference the print the content of the lines
        if (c1 == '\n' || c2 == '\n') {
            if (differenceFound) {
                cout << "Difference found at line " << l << " : " << line1 << " != " << line2 << endl;
                return;
            }
            l++;
            line1.clear();
            line2.clear();
        }
    }
// there is no difference
    if (!differenceFound) {
        cout << "Files are identical." << endl;
    }
    myfile1.close();
    myfile2.close();
}
void word_by_word(ifstream& myfile1, ifstream& myfile2) {
    string word1, word2;
    int w = 1;

// at the end of the line (lines) if there is a difference the print the different words
    while (myfile1 >> word1 && myfile2 >> word2) {
        if (word1 != word2) {
            cout << "Difference found at word " << w << " : " << word1 << " != " << word2 << endl;
        }
            w++;
    }
    if (word1 != word2) {
        cout << "Difference found at word " << w << " : " << word1 << " != " << word2 << endl;
    }
    // there is no difference
    else {
        cout << "Files are identical." << endl;
    }

    myfile1.close();
    myfile2.close();
}

int main() {
    string file1, file2;
    cout << "please enter file1 name : ";
    cin >> file1;
    cout << endl;
    cout << "please enter file12 name : ";
    cin >> file2;
    cout << endl;

    //open the files
    ifstream myfile1(file1);
    ifstream myfile2(file2);

    if (!myfile1 || !myfile2) {
        cout << "Failed to open one file or both of them." << endl;
        return 1;
    }
    cout << "1-if you want to compare the 2 files character by character please enter 1 :-\n2-if you want to compare the 2 files word by word please enter 2 :- " << endl;
    int x;
    cin >> x;
    switch (x) {
        case 1 :
            character_by_character(myfile1, myfile2);
            break;
        case 2:
            word_by_word(myfile1, myfile2);
            break;
        default:
            cout << "Invalid input. Please enter 1 or 2." << endl;
    }
    return 0;
}